import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
import {Jeu} from '../_models/jeu';
import {GamesService} from '../_services/games.service';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {MecaniquesService} from "../_services/mecaniques.service";
import {map} from "rxjs/operators";

@Component({
  selector: 'app-add-game',
  templateUrl: './add-game.component.html',
  styleUrls: ['./add-game.component.css']
})
export class AddGameComponent implements OnInit {

  games$: Observable<any[]>;
  game: Jeu;
  currLangue: string;

  readonly categories: string[] = [];
  readonly mecaniques: string[] = [];
  readonly editeurs: string[] = [];
  readonly themes: string[] = [];
  readonly langues: string[] = [];

  formulaire = new FormGroup({
    nom: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(100)]),
    description: new FormControl('', [Validators.required]),
    theme: new FormControl('', [Validators.required]),
    editeur: new FormControl('', [Validators.required]),
    mecanique: new FormControl('', [Validators.required]),
    url_media: new FormControl('', []),
    categorie: new FormControl('', [Validators.required]),
    regles: new FormControl('', [Validators.required]),
    langue: new FormControl('', [Validators.required]),
    nbJoueur: new FormControl('', [Validators.required, Validators.min(2), Validators.max(8)]),
    ageMin: new FormControl('', [Validators.required, Validators.min(1), Validators.max(16)]),
    poids: new FormControl('', [Validators.required, Validators.min(0.100), Validators.max(5.00)]),
    duree: new FormControl('', [Validators.required])

  });


  constructor(private mecaService: MecaniquesService, private gameService: GamesService, private route: ActivatedRoute, private router: Router, private http: HttpClient) {
    const id = +this.route.snapshot.paramMap.get('id');
    this.games$ = gameService.list();
  }

  ngOnInit(): void {
    this.games$.subscribe(
      game => {
        game.forEach(g => {
          this.game = g;
          if (this.langues.indexOf(g.langue) === -1) {
            this.langues.push(g.langue.valueOf());
          }
          if (this.editeurs.indexOf(g.editeur_id.nom) === -1) {
            this.editeurs.push(g.editeur_id.nom.valueOf());
          }
          if (this.categories.indexOf(g.categorie) === -1) {
            this.categories.push(g.categorie.valueOf());
          }
          if (this.themes.indexOf(g.theme_id.nom) === -1) {
            this.themes.push(g.theme_id.nom.valueOf());
          }
        });
      }
    );
    this.mecaService.getMeca().subscribe(
      meca => {
        console.log('le meca', meca);
        meca.forEach(m => {
            this.mecaniques.push(m.nom);
          }
        );
      });
    this.currLangue = this.langue.value;
  }


  get nom()
    :
    AbstractControl {
    return this.formulaire.get('nom');
  }

  get description()
    :
    AbstractControl {
    return this.formulaire.get('description');
  }

  get theme()
    :
    AbstractControl {
    return this.formulaire.get('theme');
  }

  get editeur()
    :
    AbstractControl {
    return this.formulaire.get('editeur');
  }

  get mecanique()
    :
    AbstractControl {
    return this.formulaire.get('mecanique');
  }

  get url_media()
    :
    AbstractControl {
    return this.formulaire.get('url_media');
  }

  get categorie()
    :
    AbstractControl {
    return this.formulaire.get('categorie');
  }

  get regles()
    :
    AbstractControl {
    return this.formulaire.get('regles');
  }

  get langue(): AbstractControl {
    return this.formulaire.get('langue');
  }

  get nbJoueur()
    :
    AbstractControl {
    return this.formulaire.get('nbJoueur');
  }

  get ageMin()
    :
    AbstractControl {
    return this.formulaire.get('ageMin');
  }

  get poids()
    :
    AbstractControl {
    return this.formulaire.get('poids');
  }

  get duree()
    :
    AbstractControl {
    return this.formulaire.get('duree');
  }


  onSubmit(): void {
    const httpOptions = {
      headers: new HttpHeaders({
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      })
    };
    this.http.post<any>('http://localhost:8000/api/jeux', {
      nom: this.nom.value,
      description: this.description.value,
      theme: this.theme.value,
      editeur: this.editeur.value,
      langue: this.langue.value,
      age: this.ageMin.value,
      poids: this.poids.value,
      nombre_joueurs: this.nbJoueur.value,
      categorie: this.categorie.value,
      duree: this.duree.value,
      regles: this.regles.value,

    }, httpOptions).subscribe((rep) => {
      if (rep.data.value === 'User successfully registered') {
        this.router.navigate(['']);
      }
    });
  }
}
