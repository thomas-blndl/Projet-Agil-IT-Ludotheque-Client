export interface UserInfo {
  id: number;
  nom: string;
  prenom: string;
  pseudo: string;
  email: string;
  created_at: string;
  updated_at: string;
}
